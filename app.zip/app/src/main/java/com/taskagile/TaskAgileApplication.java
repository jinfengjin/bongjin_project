package com.taskagile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskAgileApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskAgileApplication.class, args);
	}

}
